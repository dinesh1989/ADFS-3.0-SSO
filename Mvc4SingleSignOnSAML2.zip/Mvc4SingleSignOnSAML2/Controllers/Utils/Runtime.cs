﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc4SingleSignOnSAML2.Controllers.Utils
{
    public class Runtime
    {
        public static String ApiAccessToken { get; set; }
        public static String NameID { get; set; }
        public static string RefreshToken { get; set; }
        public static string ExpireTime { get; set; }

    }
}